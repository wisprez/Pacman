# Pac-Man License Server

## Run
1. Install Node.js 18+.
2. Set `ADMIN_TOKEN` and `HMAC_SECRET` as environment variables (do not use the example values in production).
3. Run `node server.js`.

## Create a license
POST `/admin/create` with header `X-Admin-Token` and JSON `{ "owner": "customer name", "expiresAt": null }`.

## Activate
POST `/activate` with JSON `{ "license": "PM-...", "deviceId": "stable-device-id" }`.

A license binds to the first device that successfully activates it. A second device receives `LICENSE_ALREADY_BOUND_TO_ANOTHER_DEVICE`.

## Revoke
POST `/admin/revoke` with header `X-Admin-Token` and JSON `{ "license": "PM-..." }`.
