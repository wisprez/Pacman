# نسخه لایسنس‌دار Pac-Man

این بسته شامل بازی HTML و یک License Server است.

## نکته مهم
فایل HTML به‌تنهایی امنیت واقعی ایجاد نمی‌کند. قبل از پخش بازی، مقدار `LICENSE_SERVER` داخل `client/pacman.html` را به آدرس HTTPS سرور خودت تغییر بده.

## راه‌اندازی سرور
```bash
cd server
export ADMIN_TOKEN='یک-رمز-طولانی-و-تصادفی'
export HMAC_SECRET='یک-راز-خیلی-طولانی-و-تصادفی'
node server.js
```

## ساخت لایسنس
```bash
curl -X POST http://YOUR_SERVER/admin/create \
  -H 'X-Admin-Token: YOUR_ADMIN_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{"owner":"customer-1","expiresAt":null}'
```

خروجی شامل کلید `PM-...` است که برای همان مشتری می‌فرستی.

## نتیجه
- اولین دستگاهی که کلید را فعال کند، لایسنس به آن دستگاه bind می‌شود.
- دستگاه دوم همان کلید را بزند، خطای `LICENSE_ALREADY_BOUND_TO_ANOTHER_DEVICE` می‌گیرد.
- از `/admin/revoke` می‌توانی کلید را باطل کنی.
- برای امنیت واقعی، سرور را با HTTPS منتشر کن و مقدارهای پیش‌فرض رازها را عوض کن.
